function e(r){return Intl.NumberFormat("en-US",{maximumSignificantDigits:3}).format(r).replaceAll(","," ")}export{e as c};
