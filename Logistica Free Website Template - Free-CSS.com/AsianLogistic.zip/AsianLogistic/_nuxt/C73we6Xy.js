var o=(r=>(r.from="from",r.to="to",r))(o||{});export{o as R};
