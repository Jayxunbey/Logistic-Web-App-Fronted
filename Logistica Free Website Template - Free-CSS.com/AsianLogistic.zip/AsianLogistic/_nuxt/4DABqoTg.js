import{_ as e}from"./DlAUqK2U.js";import{ah as t}from"./c1m8qkdf.js";const o={};function s(r,a){return t(r.$slots,"default")}const _=e(o,[["render",s]]);export{_ as default};
